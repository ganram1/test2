sample-application folder: Sample Application with MSAL 1.1.1 libray
sample-application-msal2 folder: Sample Application with MSAL 2.0 library
sample-application-oidc folder: Sample Application with angular-auth-oidc-client 11.6 library

Document URL:
https://buzz.hms.com/sites/Security/IDM/Shared%20Documents/public/Sample%20Application%20to%20get%20Microsoft%20Azure%20ID%20and%20Access%20Token_Doc.docx?Web=1