import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';

import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { IPublicClientApplication, PublicClientApplication, InteractionType, BrowserCacheLocation, LogLevel } from '@azure/msal-browser';
import { MsalGuard, MsalInterceptor, MsalBroadcastService, MsalInterceptorConfiguration, MsalModule, MsalService, MSAL_GUARD_CONFIG, MSAL_INSTANCE, MSAL_INTERCEPTOR_CONFIG, MsalGuardConfiguration, MsalRedirectComponent } from '@azure/msal-angular';
import { FailedComponent } from './failed/failed.component';

const isIE = window.navigator.userAgent.indexOf("MSIE ") > -1 || window.navigator.userAgent.indexOf("Trident/") > -1; // Remove this line to use Angular Universal

export function loggerCallback(logLevel: LogLevel, message: string) {
  console.log(message);
}

export function MSALInstanceFactory(): IPublicClientApplication {
  return new PublicClientApplication({
    auth: {

      //
      // Applcation need to register into Azure to get client Id. 
      // Application have to confgiure with Single-page application (Authorization Code Flow with PKCE)
      // 
 
      clientId: "564d94b5-014b-45f8-ab3c-2b0efc164b12", // HMS IDM Test WebApp in HMS Cloud 

      //
      //  SSO Federation Process.
      //  HMS SSO (IDP)
      //  Azure (SP)
      //

      // Regular SSO
      // B2C_1A_HMSPROD_APPDEV_RP : Application is dev envrionment and SSO is production environment.
      // B2C_1A_HMSPROD_APPTEST_RP : Application is test envrionment and SSO is production environment.
      // B2C_1A_HMSPROD_RP : Application is production envrionment and SSO is production environment.
                
      // B2C_1A_HMSDEV_APPDEV_RP : Application is dev envrionment and SSO is dev environment.
      // B2C_1A_HMSTEST_APPTEST_RP : Application is test envrionment and SSO is test environment.

      // Strong Authentication SSO
      // B2C_1A_HMSPRODMFA_APPDEV_RP : Application is dev envrionment and SSO is production environment.
      // B2C_1A_HMSPRODMFA_APPTEST_RP : Application is test envrionment and SSO is production environment.
      // B2C_1A_HMSPRODMFA_RP : Application is production envrionment and SSO is production environment.

      authority:"https://HMSCloudAuth.b2clogin.com/HMSCloudAuth.onmicrosoft.com/B2C_1A_HMSProd_RP", // B2C_1A_HMSPROD_RP

      //  redirectUri: '/',
      knownAuthorities: ['https://hmscloudauth.b2clogin.com'],
      //knownAuthorities: ['https://hmscloudauthtest.b2clogin.com'],

      redirectUri:"https://localhost:59643/",
      postLogoutRedirectUri: '/'
    },
    cache: {
      //cacheLocation: BrowserCacheLocation.LocalStorage,
      cacheLocation:"localStorage",
      storeAuthStateInCookie: isIE, // set to true for IE 11. Remove this line to use Angular Universal
    },
    system: {
      loggerOptions: {
        loggerCallback,
        logLevel: LogLevel.Info,
        piiLoggingEnabled: false
      }
    }
  });
}

export function MSALInterceptorConfigFactory(): MsalInterceptorConfiguration {
  const protectedResourceMap = new Map<string, Array<string>>();
   protectedResourceMap.set('https://graph.microsoft.com/v1.0/me', []); // Prod environment. Uncomment to use.
 // protectedResourceMap.set('https://graph.microsoft-ppe.com/v1.0/me', ['user.read']);

  return {
    interactionType: InteractionType.Redirect,
    protectedResourceMap
  };
}

export function MSALGuardConfigFactory(): MsalGuardConfiguration {
  return { 
    interactionType: InteractionType.Redirect,
    authRequest: {
     // scopes: ['user.read']
     scopes: ['openid profile offline_access']
    },
    loginFailedRoute: '/login-failed'
  };
}

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ProfileComponent,
    FailedComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MatButtonModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
    HttpClientModule,
    MsalModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true
    },
    {
      provide: MSAL_INSTANCE,
      useFactory: MSALInstanceFactory
    },
    {
      provide: MSAL_GUARD_CONFIG,
      useFactory: MSALGuardConfigFactory
    },
    {
      provide: MSAL_INTERCEPTOR_CONFIG,
      useFactory: MSALInterceptorConfigFactory
    },
    MsalService,
    MsalGuard,
    MsalBroadcastService
  ],
  bootstrap: [AppComponent, MsalRedirectComponent]
})
export class AppModule { }
