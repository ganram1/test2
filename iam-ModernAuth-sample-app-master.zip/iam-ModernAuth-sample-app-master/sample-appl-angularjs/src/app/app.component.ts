import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MsalService, BroadcastService } from '@azure/msal-angular';
import { Component, OnInit } from '@angular/core';

const API_ENDPOINT = 'https://localhost:5001/WeatherForecast';
const graphMeEndpoint = 'https://graph.microsoft.com/v1.0/me';
const BackendApplicaitonURL = 'https://HMSCloudAuth.onmicrosoft.com/r1entportalwebbackendtest/';

const requestObj = {
  scopes: ["AccessReview.Read.All"]
 };

@Component({
  selector: 'app-root',
  templateUrl:'app.component.html',
  styles: []
})
export class AppComponent{
  profile;
  title = 'HMS IDM Sample Application';

  constructor(private authService:MsalService, private http:HttpClient){}

  getProfile() {
    console.log('Get User Profile');    
    this.http.get(graphMeEndpoint)
      .toPromise().then(profile => {
        console.log('User Profile: ' + this.profile);          
        this.profile = profile;
      }).catch(err => {
        console.log(err);
      });;
  }

  // Trigger from app.component.html

  onApiCall(){
    console.log('API call');

    // Use acquireTokenPopup
    /*
    this.authService
    .acquireTokenPopup({
      scopes: ['https://HMSCloudAuth.onmicrosoft.com/hmsidmtestapi/readidmbackendapi'], 
    })
    .then(function (tokenResponse){
      // Callback code here
      console.log(tokenResponse.accessToken);
    }).catch(function (error){
      console.log(error);
    });
*/

    // Use acquireTokenSilent
    
    this.authService
    .acquireTokenSilent({
      scopes: ['https://HMSCloudAuth.onmicrosoft.com/hmsidmtestapi/readidmbackendapi'],   
    })
    .then(function (tokenResponse){
      // Callback code here
      console.log(tokenResponse.accessToken);
    }).catch(function (error){
      console.log(error);
    });
    

    //.then((result: any) => {
    //  console.log(result);      
    // });

  }
}
