import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import {HttpClientModule} from '@angular/common/http';
import {MsalModule} from '@azure/msal-angular'

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MsalModule.forRoot({
      auth:{

        //
        // Applcation need to register into Azure to get client Id.        
        // 
 
        clientId: "564d94b5-014b-45f8-ab3c-2b0efc164b12", // HMS IDM Test WebApp in HMS Cloud 

        //
        //  SSO Federation Process.
        //  HMS SSO (IDP)
        //  Azure (SP)
        //

        // Regaular SSO
        // B2C_1A_HMSPROD_APPDEV_RP : Application is dev envrionment and SSO is production environment.
        // B2C_1A_HMSPROD_APPTEST_RP : Application is test envrionment and SSO is production environment.
        // B2C_1A_HMSPROD_RP : Application is production envrionment and SSO is production environment.
                
        // B2C_1A_HMSDEV_APPDEV_RP : Application is dev envrionment and SSO is dev environment.
        // B2C_1A_HMSTEST_APPTEST_RP : Application is test envrionment and SSO is test environment.

        // Strong Authentication SSO
        // B2C_1A_HMSPRODMFA_APPDEV_RP : Application is dev envrionment and SSO is production environment.
        // B2C_1A_HMSPRODMFA_APPTEST_RP : Application is test envrionment and SSO is production environment.
        // B2C_1A_HMSPRODMFA_RP : Application is production envrionment and SSO is production environment.

        authority:"https://HMSCloudAuth.b2clogin.com/HMSCloudAuth.onmicrosoft.com/B2C_1A_HMSProd_RP", // B2C_1A_HMSPROD_RP

        validateAuthority:false,
        redirectUri:"https://localhost:59643/"
      },
      cache:{
        cacheLocation:"localStorage",
        storeAuthStateInCookie:false
      }
    },{
      consentScopes:[
        "user.read","openid","profile"
      ]
    })

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
