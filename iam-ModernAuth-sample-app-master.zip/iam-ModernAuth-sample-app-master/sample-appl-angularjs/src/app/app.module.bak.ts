import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import { MsalInterceptor, MsalModule}  from '@azure/msal-angular'

const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MsalModule.forRoot({
      auth:{
        //
        //  SAML
        //  HMS Azure Cloud Test
        //  HMS SSO Test (IDP)
        //  Azure (SP)
        //
        
        //clientId: "bb4305b5-3de2-40e0-ba6f-00ffb12318f4",// Application Id of Application registered in B2C. Mark Test Web in HMS Cloud Test
        //authority:"https://hmscloudauthtest.b2clogin.com/hmscloudauthtest.onmicrosoft.com/B2C_1A_HMSTest_RP", //HMS SSO Federation Policy

        //
        //  SAML
        //  HMS Azure Cloud 
        //  HMS SSO (IDP)
        //  Azure (SP)
        //
 
        clientId: "564d94b5-014b-45f8-ab3c-2b0efc164b12", // HMS IDM Test WebApp in HMS Cloud 
        //clientId: "547ed889-2d1f-4a23-a030-63c5b8186408", // HMS Portal Test Web
        authority:"https://HMSCloudAuth.b2clogin.com/HMSCloudAuth.onmicrosoft.com/B2C_1A_HMSProd_RP", //HMS SSO Federation Policy

        //
        //  SAML
        //  HMS Azure Cloud 
        //  Auth0 (IDP)
        //  Azure (SP)
        //

        //clientId: "536f863a-05fb-46b5-80f0-207520b4fb29", // HMS Portal Auth0 Dev
        //authority:"https://hmscloudauth.b2clogin.com/hmscloudauth.onmicrosoft.com/B2C_1A_Auth0_TEST_RP", //signup-signin userflow
        
        //validateAuthority:false,
        
        redirectUri:"https://localhost:59643/"
      },
      cache:{
        //cacheLocation:"sessionStorage",
        cacheLocation:"localStorage",
        storeAuthStateInCookie:isIE
      }
    },{
      popUp: !isIE,      
      consentScopes:[
        "read","openid","profile","api.readwrite.all","AccessReview.Read.All"
      ],      
      unprotectedResources: [],
      
      protectedResourceMap: [
        ['https://HMSCloudAuth.onmicrosoft.com/r1entportalwebbackendtest', ['api.readwrite.all']],
        ['https://graph.microsoft.com/v1.0/me', ['AccessReview.Read.All']]        
      ],
      
      extraQueryParameters: {}                  
    })
  ],
 
  /*
  providers: [ 
    {
      provide: HTTP_INTERCEPTORS, 
      useClass: MsalInterceptor, 
      multi: true
    }
  ],
  */

  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

