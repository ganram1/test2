
Function Description:

Login function:
File: navbar.component.ts
Method: onLogin() 
MSAL method: authService.loginPopup()
Azure will return Id Token.

Azure Access Token:
File: app.component.ts
Method: onApiCall()
MSAL method: authService.acquireTokenPopup or authService.acquireTokenSilent
Azure will return Access Token.

Logout function:
File: navbar.component.ts
Method: onLogin() 
MSAL method: authService.logout()
SSO Logout URL: https://prodidm.hms.com/sso/hms_external_logout.html


Command:

npm install
npm install -g @angular/cli
ng serve --port 59643 --ssl --ssl-key localhost.key  --ssl-cert localhost.crt

Navigate to https://localhost:59643
