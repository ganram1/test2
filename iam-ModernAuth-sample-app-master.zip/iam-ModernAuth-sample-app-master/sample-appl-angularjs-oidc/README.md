# Oidc

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 12.0.0.


Login function:
File: nav-menu.component.ts

Method: login() 
OIDC method: oidcSecurityService.authorize();
Azure will return Id and Access Token.
If you don't need Azure Access Token, set scope: 'openid profile email', 

Azure Access Token:
File: nav-menu.component.ts
Method: requestAccessToken()
OIDC method: oidcSecurityService.getToken
Azure will return Access Token.

Logout function:
File: nav-menu.component.ts
Method: logout() 
OIDC method: oidcSecurityService.logoff()
SSO Logout URL: https://prodidm.hms.com/sso/hms_external_logout.html


Command:

npm install
npm install -g @angular/cli
ng serve --port 59643 --ssl --ssl-key localhost.key --ssl-cert localhost.crt

Navigate to https://localhost:59643
