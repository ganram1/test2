import { APP_INITIALIZER, NgModule } from '@angular/core';
import { AuthModule, LogLevel, OidcConfigService, OidcSecurityService } from 'angular-auth-oidc-client';

export function loadConfig(oidcConfigService: OidcConfigService) {
  return () =>
    oidcConfigService.withConfig({

     stsServer: 'https://login.microsoftonline.com/hmscloudauth.onmicrosoft.com/v2.0',

     //
     //  SSO Federation Process.
     //  HMS SSO (IDP)
     //  Azure (SP)
     //

     // Regular SSO
     // B2C_1A_HMSPROD_APPDEV_RP : Application is dev envrionment and SSO is production environment.
     // B2C_1A_HMSPROD_APPTEST_RP : Application is test envrionment and SSO is production environment.
     // B2C_1A_HMSPROD_RP : Application is production envrionment and SSO is production environment.
                
     // B2C_1A_HMSDEV_APPDEV_RP : Application is dev envrionment and SSO is dev environment.
     // B2C_1A_HMSTEST_APPTEST_RP : Application is test envrionment and SSO is test environment.
 
     // Strong Authentication SSO
     // B2C_1A_HMSPRODMFA_APPDEV_RP : Application is dev envrionment and SSO is production environment.
     // B2C_1A_HMSPRODMFA_APPTEST_RP : Application is test envrionment and SSO is production environment.
     // B2C_1A_HMSPRODMFA_RP : Application is production envrionment and SSO is production environment.

     authWellknownEndpoint: 'https://HMSCloudAuth.b2clogin.com/HMSCloudAuth.onmicrosoft.com/B2C_1A_HMSProd_RP/v2.0/.well-known/openid-configuration', // B2C_1A_HMSPROD_RP

     //
     // Applcation need to register into Azure to get client Id. 
     // Application have to confgiure with Single-page application (Authorization Code Flow with PKCE)
     //  
     clientId: '564d94b5-014b-45f8-ab3c-2b0efc164b12', // HMS IDM Test WebApp
      
     redirectUrl: window.location.origin,
     
     //
     // OIDC will return id and access token with this scope.
     // if you only want OIDC return id token, please comment this scope value.
     //
     scope: 'openid profile https://HMSCloudAuth.onmicrosoft.com/generalapi/general-access',
      
     //
     // Please uncomment this scope value if you only want OIDC return id token.
     //
     //scope: 'openid profile email',

     responseType: 'code',
     silentRenew: true,
     maxIdTokenIatOffsetAllowedInSeconds: 600,
     issValidationOff: true,
     autoUserinfo: false,
     silentRenewUrl: window.location.origin + '/silent-renew.html',
     useRefreshToken: true,
     logLevel: LogLevel.Debug,
     customParams: {
        prompt: 'select_account', // login, consent
     },
    });
}

@NgModule({
  imports: [AuthModule.forRoot()],
  providers: [
    OidcSecurityService,
    OidcConfigService,
    {
      provide: APP_INITIALIZER,
      useFactory: loadConfig,
      deps: [OidcConfigService],
      multi: true,
    },
  ],
  exports: [AuthModule],
})
export class AuthConfigModule {}
